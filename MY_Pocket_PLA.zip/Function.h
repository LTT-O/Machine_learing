#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED


#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;

#define DIMESION 5



//存储训练样本，input为x，output为y
struct record{
    double input[DIMESION];
    double ouput;
};


void Pocket_PLA(double*,double*,vector<record> ,int);
double Get_error_rate(double*,vector<record>);
double multiply_w_x(double*,double*);
void add(double*,double*);
void multiply_x_y(double*,double*,int);
int sign(double);
void openfile();
void getdata(ifstream &,vector<record>&);


#endif // FUNCTION_H_INCLUDED
