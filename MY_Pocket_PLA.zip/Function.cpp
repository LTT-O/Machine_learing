#include "Function.h"


int Time;                   //修改次数
int Train_num;              //训练样本数
char *Train_file = "training.txt";



/**获取样本数据*/
void getdata(ifstream &datafile,vector<record>&trainingdata)
{
    //cout << "getdata" << endl;
    while(!datafile.eof())
    {
        record temp;
        temp.input[0] = 1;
        for(int i = 1; i < DIMESION; i++)
            datafile>>temp.input[i];
        datafile>>temp.ouput;
        trainingdata.push_back(temp);
    }
    datafile.close();
    Train_num = trainingdata.size();
}


/**计算sign值*/
int sign(double x)
{
    return (x>0)? 1:-1;
}


/**计算(y*x)*/
void multiply_x_y(double *result,double *x,int y)
{
    for(int i = 0; i < DIMESION; i++)
        result[i] = x[i]*y;
}

/**W的修改*/
void add(double *w,double *x_y)
{
    for(int i = 0; i < DIMESION; i++)
        w[i] += x_y[i];
}

/**计算(W*X)*/
double multiply_w_x(double *w,double *x)
{
    //cout << "1" <<endl;
    double temp = 0;
    for(int i = 0; i < DIMESION; i++)
        temp += w[i]*x[i];
    return temp;
}

/**计算当前W的错误率*/
double Get_error_rate(double *w,vector<record> data)
{
    double error_num = 0.0;
    int n = data.size();
    for(int i = 0; i < n; i++)
    {
        if(sign(multiply_w_x(w,data[i].input)) != data[i].ouput)
            error_num++;
    }
    return error_num/n;
}


void Pocket_PLA(double *pocketWeights,double *weights,vector<record> trainingSet,int iteration)
{
	int index = 0;
	int iter= 1;
	int n = trainingSet.size();
    while(iter <= iteration)
    {

        if(sign(multiply_w_x(weights,trainingSet[index].input)) != trainingSet[index].ouput)
        {
            ///cout << "2" << endl;
            double temp[DIMESION];
            multiply_x_y(temp,trainingSet[index].input,trainingSet[index].ouput);

            add(weights,temp);
            ///**贪心算法
            if(Get_error_rate(weights,trainingSet) < Get_error_rate(pocketWeights,trainingSet))
            {
                for(int i = 0; i < DIMESION; i++)
                    pocketWeights[i] = weights[i];
            }//*/
            iter++;
        }
        if(index == n-1)
            index = 0;
		else
            index++;
    }

}











