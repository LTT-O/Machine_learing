#include <iostream>
#include "Function.h"
using namespace std;

//char *Text_file = "test.txt";




int main()
{
    double weights[DIMESION]={0,0,0,0,0};
    double pocketweights[DIMESION]={0,0,0,0,0};
    vector<record> trainingdata;
    vector<record> testdata;
    ifstream datafile1("training.txt");
	ifstream datafile2("test.txt");
	if(datafile1.is_open()&&datafile2.is_open()){
		getdata(datafile1,trainingdata);
		getdata(datafile2,testdata);
		//cout << "finish" <<endl;
	}
	else{
		cout<<"can not open file!"<<endl;
		exit(1);
	}
	cout << "大小 = " <<trainingdata.size() << endl;
    double ave_error = 0.0;
    for(int i = 1; i <= 2000; i++)
    {
        random_shuffle(trainingdata.begin(),trainingdata.end());
//		for(int j=0;j<5;j++){  //注意，这里需要初始化！！！不初始化值会乱码，程序出错！！！
//		    weights[j]=0.0;
//		    pocketweights[j]=0.0;
//		}
        Pocket_PLA(pocketweights,weights,trainingdata,100);
        double train_error = Get_error_rate(pocketweights,trainingdata);
        double test_error = Get_error_rate(pocketweights,testdata);
        ave_error += test_error;
        cout<<"第"<<i<<"次实验---"<<"training error:"<<train_error<<" test error:"<<test_error<<endl;
    }
    cout << "测试原本平均错误率为： " << ave_error/2000.0 << endl;
    return 0;
}
