#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED


#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
using namespace std;

#define DIMESION 5
struct record{
    double input[DIMESION];
    double ouput;
};

void PLA();
//double Get_error_rate(double*,vector<record>);
double multiply_w_x(double*,double*);
void add(double*,double*);
void multiply_x_y(double*,double*,int);
int sign(double);
void openfile();
void getdata(ifstream &);


#endif // FUNCTION_H_INCLUDED
