#include <iostream>
#include "Function.h"
using namespace std;

int main()
{

    //cout << "Hello world!" << endl;
//    double Time = 0;
//    for(int i = 0; i < 2000; i++)
//    {
//        int n = PLA();
//        Time += n;
//        cout << "�� " << i << " ��" << "������ " << n << " ��"<< endl;
//    }
//
//    cout << "Time = " << Time/2000.0 << endl;
    PLA();
    return 0;
}
