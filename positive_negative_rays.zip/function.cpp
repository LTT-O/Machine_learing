
#include "function.h"
#define DATASIZE 20

//ѵ������
//vector<record> trainingData;
/**��������*/
//1.sign����
int sign(double x)
{
    return (x>0)?1:-1;
}

//2.[-1,1]����20���������Ϊѵ������
void getData(vector<record>& trainingData)
{
    record temp;
    for(int i = 0; i < DATASIZE; i++)
    {
        temp.x = 2.0*rand()/double(RAND_MAX)-1.0;
        temp.y = sign(temp.x);
        trainingData.push_back(temp);
    }
//    cout << "[";
//    for(auto i : trainingData)
//        cout << i.x << " , ";
//    cout << "]"<<endl;
}

//3.����20%����
void getNoise(vector<record>& trainingData)
{
    for(int i = 0; i < DATASIZE; i++)
    {
        double num = rand()/double(RAND_MAX);
        if(num < 0.2)
            trainingData[i].y *= -1;
    }
}

//4.��20��������������
//��������record������ʽ
bool myCompare(record x1,record x2)
{
    return x1.x<x2.x;
}
void dataSort(vector<record>& trainingdata)
{
    sort(trainingdata.begin(),trainingdata.end(),myCompare);
}
//5.����ѵ�����ݺ�hyphothesis�����Ӧ�Ĵ�����
double calculateError(vector<record> &trainingData,hyphothesis &h)
{
    double error=0.0;
    for(int i = 0; i < DATASIZE; i++)
    {
        int temp = h.s*sign(trainingData[i].x-h.theta);
        if(temp != trainingData[i].y)
            error++;
    }
    return error/(double)DATASIZE;
}
//6.s=1��s=-1,��42��h�����м�����С��Ein
double E_in(vector<record> &trainingData,hyphothesis &bestH)
{

	hyphothesis temp;
	double min_errorRate = 1.0;
	//s = 1
	for(int i = 0; i < DATASIZE; i++)
    {
        temp.s = 1;
        if(i == 0)
            temp.theta = (trainingData[i].x-1.0)/2.0;
        else if(i == DATASIZE-1)
            temp.theta = (trainingData[i].x+1.0)/2.0;
        else
            temp.theta = (trainingData[i-1].x+trainingData[i].x)/2.0;
        double errorRate = calculateError(trainingData,temp);
        if(errorRate < min_errorRate)
        {
            bestH = temp;
            min_errorRate = errorRate;
        }
    }
    //s = -1
	for(int i = 0; i < DATASIZE; i++)
    {
        temp.s = -1;
        if(i == 0)
            temp.theta = (trainingData[i].x-1.0)/2.0;//thetaȡֵ��thetaС����С
        else if(i == DATASIZE-1)
            temp.theta = (trainingData[i].x+1.0)/2.0;//thetaȡֵ�������

        else
            temp.theta = (trainingData[i-1].x+trainingData[i].x)/2.0;//thetaȡֵ������֮��
        double errorRate = calculateError(trainingData,temp);
        if(errorRate < min_errorRate)
        {
            bestH = temp;
            min_errorRate = errorRate;
        }
    }
    return min_errorRate;
}

//7.����Eout
double E_out(hyphothesis &bestH)
{
	return 0.5 + 0.3 * double(bestH.s) * (double)(fabs(bestH.theta) - 1.0);
}








