#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

//��������
struct record
{
    double x;
    int y;
};
//hyphothesis----h(x)=s*sign(x-theta)
struct hyphothesis
{
    int s;
    double theta;
};
int sign(double x);
void getData(vector<record>& trainingData);
void getNoise(vector<record>& trainingData);
bool myCompare(record x1,record x2);
void dataSort(vector<record>& trainingdata);
double calculateError(vector<record> &trainingData,hyphothesis &h);
double E_in(vector<record> &trainingData,hyphothesis &bestH);
double E_out(hyphothesis &bestH);




#endif // FUNCTION_H_INCLUDED
