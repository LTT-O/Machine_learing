#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>

#define DEMENSION 9

using namespace std;

//����9ά����������
struct record
{
    double x[DEMENSION];
    int y;
};
//����һά�ȵ�x��y
struct singleDemension
{
    double x;
    int y;
};
//hyphothesis
struct hyphothesis
{
    int s;
    double theta;
};


void getData(fstream &file,vector<record> &traindata);
int sign(double x);
bool Mycompare(singleDemension x1,singleDemension x2);
void dataSort(vector<singleDemension>& s);
double calculateError(vector<singleDemension> &data,hyphothesis &h,int n);
double E_in(vector<record> &data,hyphothesis &bestH,int &bestDemension,int n);
double E_out(vector<record> &textdata,int bestDemension,hyphothesis &bestH,int n);















#endif // FUNCTION_H_INCLUDED
