#include <iostream>
#include "function.h"
using namespace std;

int main()
{
    vector<record> traindata;
    vector<record> testdata;
    fstream train_file("train.txt");
    fstream test_file("text.txt");
    if(train_file.is_open() && test_file.is_open())
    {
        getData(train_file,traindata);
        getData(test_file,testdata);
    }
    else
    {
        cout << "���ļ�ʧ��" << endl;
        exit(-1);
    }
    double E_in_errorRate,E_out_errorRate;
    int trainSize = traindata.size();
    int testSize = testdata.size();
    int bestDemension = 0;
    hyphothesis bestH = {0,0};
    E_in_errorRate = E_in(traindata,bestH,bestDemension,trainSize);
    E_out_errorRate = E_out(testdata,bestDemension,bestH,testSize);
    cout << "H=(" << bestH.s << "," << bestH.theta <<")" <<endl;
    cout << testSize <<endl;
    cout<<"���ά��Ϊ��"<<bestDemension<<",   ��СE_inΪ��"<<E_in_errorRate<<",    ���Ӧ��E_outΪ��"<<E_out_errorRate<<endl;

    return 0;
}
