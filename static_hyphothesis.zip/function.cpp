#include "function.h"

/**����*/
//1.���ļ��ж�ȡ����
void getData(fstream &file,vector<record> &traindata)
{
    while(!file.eof())
    {
        record temp;
        for(int i = 0; i < DEMENSION; i++)
            file>>temp.x[i];
        file>>temp.y;
        traindata.push_back(temp);
    }
    file.close();
}

//2.sign
int sign(double x)
{
    return (x>0)?1:-1;
}

//3.����ȽϷ���
bool Mycompare(singleDemension x1,singleDemension x2)
{
    return x1.x < x2.x;
}

//4.������ĵ�άx��������
void dataSort(vector<singleDemension>& s)
{
    sort(s.begin(),s.end(),Mycompare);
}

//5.������ĵ�ά��x���������
double calculateError(vector<singleDemension> &data,hyphothesis &h,int n)
{
    double error = 0.0;
    int temp;
    for(int i = 0; i < n; i++)
    {
        temp = h.s*sign(data[i].x-h.theta);
        if(data[i].y != temp)
            error++;
    }
    return error/(double)n;
}


//6.��Ӧÿ��ά�ȵ�ÿ��h��������ʣ���¼��С�������Լ���Ӧh�Ͷ�Ӧά��
double E_in(vector<record> &data,hyphothesis &bestH,int &bestDemension,int n)
{

	double min_errorRate = 1.0;
	hyphothesis temp_h = {0,0};
    for(int i = 0; i < DEMENSION; i++)
    {
        vector<singleDemension> sinDemension;
        for(int j = 0; j < n; j++)
        {
            singleDemension temp_data;
            temp_data.x = data[j].x[i];
            temp_data.y = data[j].y;
            sinDemension.push_back(temp_data);
        }

        dataSort(sinDemension);
        //s = 1;
        for(int k = 0; k < n+1; k++)
        {
            //cout << "1";
            temp_h.s = 1;
            if(k == 0)
                temp_h.theta = (sinDemension[k].x-1.0)/2.0;
            else if(k == n)
                temp_h.theta = (sinDemension[k-1].x+1.0)/2.0;
            else
                temp_h.theta = (sinDemension[k-1].x+sinDemension[k].x)/2.0;
            double error = calculateError(sinDemension,temp_h,n);
            if(error < min_errorRate)
            {
               // cout << "1";
                min_errorRate = error;
                bestH = temp_h;
                bestDemension = i+1;
            }
        }
        //s = -1;
        for(int k = 0; k < n+1; k++)
        {
            temp_h.s = -1;
            if(k == 0)
                temp_h.theta = (sinDemension[k].x-1.0)/2.0;
            else if(k == n)
                temp_h.theta = (sinDemension[k-1].x+1.0)/2.0;
            else
                temp_h.theta = (sinDemension[k-1].x+sinDemension[k].x)/2.0;
            double error = calculateError(sinDemension,temp_h,n);
            if(error < min_errorRate)
            {
               // cout << "2";
                min_errorRate = error;
                bestH = temp_h;
                bestDemension = i+1;
            }
        }
    }
    return min_errorRate;
}



//7.��������h�����������E_out
double E_out(vector<record> &textdata,int bestDemension,hyphothesis &bestH,int n)
{
    cout << bestDemension <<endl;
    vector<singleDemension> bestDemensionData;
    singleDemension temp = {0,0};
    for(int i = 0; i < n; i++)
    {
        temp.x = textdata[i].x[bestDemension-1];
        temp.y = textdata[i].y;
        bestDemensionData.push_back(temp);
    }
    dataSort(bestDemensionData);

    return calculateError(bestDemensionData,bestH,n);
}
