#include <iostream>
#include <cmath>
#include "Eigen\Dense"

using namespace Eigen;
using namespace std;

void fun(double &u,double &v);
int main()
{

//    double u = 0.0,v = 0.0;
//    fun(u,v);
//    cout << "(" << u << "," << v <<")" << endl;
//    double E = exp(u)+exp(2*v)+exp(u*v)+pow(u,2)-2*u*v+2*pow(v,2)-3*u-2*v;
//    cout << "E = " << E << endl;

    int a[10];
    a[0] = 10;
    cout << *(a+0) << endl;



    return 0;
}

void fun(double &u,double &v)
{
    for(int i = 0; i < 5; i++)
    {
        u -= 0.01*(exp(u)+v*exp(u)+2.0*u-3*v-3);
        v -= 0.01*(2*exp(v)+u*exp(v)-2*u+4*v-2);
    }
}
