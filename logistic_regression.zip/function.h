#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED

#include <iostream>
#include "Eigen/Dense"

using namespace Eigen;
using namespace std;

#define X1min -1
#define X1max  1
#define X2min -1
#define X2max  1
#define  N   1000


int sign(double );
void getRandData(Matrix<double,N,3>& ,Matrix<double,N,1> &);
void getNoise(Matrix<double,N,1>& );
void featerTransform(Matrix<double,N,3> &,Matrix<double,N,6> & );
void linearRegression(Matrix<double,N,6> & ,Matrix<double,N,1> &,Matrix<double,6,1> &);
double calcuE(Matrix<double,N,6> &,Matrix<double,N,1> &,Matrix<double,6,1> &);





#endif // FUNCTION_H_INCLUDED
