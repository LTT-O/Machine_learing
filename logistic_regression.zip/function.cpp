#include "function.h"

int sign(double x)
{
    return (x>0)?1:-1;
}

void getRandData(Matrix<double,N,3> &X,Matrix<double,N,1> &Y)
{
    for(int i = 0; i < N; i++)
    {
        X(i,0) = 1;
        X(i,1) = (double)(X1max-X1min)*rand()/RAND_MAX-(X1max-X1min)/2.0;
        X(i,2) = (double)(X2max-X2min)*rand()/RAND_MAX-(X2max-X2min)/2.0;
        Y(i,0) = sign(X(i,1)*X(i,1)+X(i,2)*X(i,2)-0.6);
    }
}

void getNoise(Matrix<double,N,1> &Y)
{
    for(int i = 0; i < N; i++)
    {
        if((rand()/RAND_MAX) < 0.1)
            Y(i,0) *= -1;
    }
}

void featerTransform(Matrix<double,N,3> &X,Matrix<double,N,6> &Z)
{
    for(int i = 0; i < N; i++)
    {
        Z(i,0) = 1;
        Z(i,1) = X(i,1);
        Z(i,2) = X(i,2);
        Z(i,3) = X(i,1)*X(i,2);
        Z(i,4) = X(i,1)*X(i,1);
        Z(i,5) = X(i,2)*X(i,2);
    }
}


void linearRegression(Matrix<double,N,6> &Z,Matrix<double,N,1> &Y,Matrix<double,6,1> &W)
{
    W = (Z.transpose()*Z).inverse()*Z.transpose()*Y;
}

double calcuE(Matrix<double,N,6> &Z,Matrix<double,N,1> &Y,Matrix<double,6,1> &W)
{
    double E_err = 0;
    Matrix<double,N,1> temp = Z*W;
    for(int i = 0; i < N; i++)
    {
        if(sign(temp(i,0)) != Y(i,0))
            E_err++;
    }
    return double(E_err/N);
}
