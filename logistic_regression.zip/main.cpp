#include <iostream>
#include <algorithm>
#include "function.h"
using namespace std;

int main()
{
    Matrix<double,N,3> X;
    Matrix<double,N,3> Xtest;
    Matrix<double,N,6> Z;
    Matrix<double,N,6> Ztest;
    Matrix<double,N,1> Y;
    Matrix<double,N,1> Ytest;
    Matrix<double,6,1> weight;
    Matrix<double,6,1> totalweight;

    totalweight<<0,0,0,0,0,0;

	double total_Ein = 0.0;
	double total_Eout = 0.0;
    int seed[N];
    for(int i = 0; i < N; i++)//����1000�Σ�ÿ����Ҫ1�����ӣ�����������rand��ʼ������
        seed[i] = rand();
    //vector<double> num;
    double E_in,E_out,Min_err = 1;
    Matrix<double,6,1> temp;
    for(int i = 0; i < 1000; i++)
    {
        srand(seed[i]);
        getRandData(X,Y);
        getRandData(Xtest,Ytest);
        getNoise(Y);
        getNoise(Ytest);
        featerTransform(X,Z);
        featerTransform(Xtest,Ztest);

        linearRegression(Z,Y,weight);


        E_in = calcuE(Z,Y,weight);
        E_out = calcuE(Ztest,Ytest,weight);
        total_Ein += E_in;
        total_Eout += E_out;
        if(E_in < Min_err)
        {
            Min_err = E_in;
            temp = weight;
        }

        //num.push_back(E_in);
		totalweight += weight;
		//cout<<"NO:"<<i<<" ,  Ein = "<<calcuE(Z,Y,weight)<<"  ,  Eout = "<<calcuE(Ztest,Ytest,weight)<<endl;
    }


	cout<<"Average E_in:"<<total_Ein / 1000.0<<endl;
	cout<<"Average E_out:"<<total_Eout / 1000.0<<endl;
	cout<<totalweight/1000<<endl;
	cout <<"MinErr = " << Min_err <<endl;
	cout << temp << endl;



    return 0;
}
